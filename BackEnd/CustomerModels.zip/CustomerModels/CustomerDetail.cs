﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CustomerModels
{
    [Table("Customer")]
    public class CustomerDetail
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "FirstName is required.")]
        public string FirstName { get; set; }
        public string LastName { get; set; }
        [Required(ErrorMessage = "Mobile number is required.")]
        public int Mobile { get; set; }
        [Required(ErrorMessage = "Gender is required.")]
        public string Gender { get; set; }

    }
}
