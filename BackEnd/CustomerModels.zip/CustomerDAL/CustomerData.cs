﻿using CustomerModels;
using System.Data.Entity;

namespace CustomerDAL
{
    public class CustomerData : DbContext
    {
        public CustomerData() : base("CustomerDataBase")
        {

        }
            
        public DbSet<CustomerDetail> Customers { get; set; }


    }
}
