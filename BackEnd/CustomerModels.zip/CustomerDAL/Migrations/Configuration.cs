namespace CustomerDAL.Migrations
{
    using CustomerModels;
    using System.Data.Entity.Migrations;

    internal sealed class Configuration : DbMigrationsConfiguration<CustomerData>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
            ContextKey = "CustomerDAL.CustomerData";
        }

        protected override void Seed(CustomerData context)
        {
            context.Customers.AddOrUpdate(x => x.Id,
              new CustomerDetail { FirstName = "Ramu", LastName = "Alagappan", Gender = "Male", Mobile = 123456, Id=1 },
              new CustomerDetail { FirstName = "Raj", LastName = "Kumar", Gender = "Male", Mobile = 674321, Id = 2 }
            );
        }
    }
}
