﻿using CustomerDAL;
using CustomerIBL;
using CustomerModels;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CustomerBL
{
    public class CustomerService : ICustomerService
    {
        CustomerData _customerDatacontext = new CustomerData();

        public IEnumerable<CustomerDetail> GetCustomers()
        {
            try
            {
                return _customerDatacontext.Customers.ToList();               
            }
            catch (Exception ex)
            {
                //log it and throw
                throw ex;
            }
        }

        public bool AddCustomer(CustomerDetail customer)
        {
            try
            {
                _customerDatacontext.Customers.Add(customer); 
                return _customerDatacontext.SaveChanges() == 1 ? true : false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
