﻿using CustomerModels;
using System.Collections.Generic;

namespace CustomerIBL
{
    public interface ICustomerService
    {
        IEnumerable<CustomerDetail> GetCustomers();

        bool AddCustomer(CustomerDetail customer);
    }
}
