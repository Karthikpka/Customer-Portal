﻿using CustomerIBL;
using CustomerModels;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
    

namespace CustomerService.Controllers
{
    /// <summary>
    /// Class contains all the action related to Customer
    /// </summary>
    [RoutePrefix("api/Customer")]
    public class CustomerController : ApiController
    {
        private readonly ICustomerService _customerService;
        public CustomerController(ICustomerService customerService)
        {
            _customerService = customerService;
        }
        /// <summary>
        /// Used to fetch all Customers from DB
        /// </summary>
        /// <returns>List of CustomerDetail</returns>     
        [Route("GetCustomers")]
        public async Task<IHttpActionResult> GetAllCustomers()
        {
            try
            {
                var data= _customerService.GetCustomers();
                if (data == null)
                {
                    throw new HttpResponseException(HttpStatusCode.NotFound);
                }

                return await Task.FromResult(Ok(data));
            }
            catch
            {                
                throw new HttpResponseException(HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Used to add new Customer to DB
        /// </summary>
        /// <param name="customerDetail">new model to add in DB</param>
        /// <returns>boolean</returns>
        [HttpPost]
        [Route("AddCustomer")]
        public HttpResponseMessage AddCustomer(CustomerDetail customerDetail)
        {
            try
            {
                if (!ModelState.IsValid)
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);

                if(_customerService.AddCustomer(customerDetail))
                    return new HttpResponseMessage(HttpStatusCode.OK);
                else
                    return new HttpResponseMessage(HttpStatusCode.InternalServerError);
            }
            catch
            {
                throw new HttpResponseException(HttpStatusCode.InternalServerError);
            }
        }
    }
}
